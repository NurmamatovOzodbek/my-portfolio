export const navbarLink = [
  {
    id: 1,
    title: "Home",
    navLink: '/'
  },
  {
    id: 2,
    title: "About",
    navLink: '/about'
  },
  {
    id: 3,
    title: "Tech Stack",
    navLink: '/techstack'
  },
  {
    id: 4,
    title: "Projects",
    navLink: '/projects'
  },
  {
    id: 5,
    title: "Contact",
    navLink: '/contact'
  },
];
