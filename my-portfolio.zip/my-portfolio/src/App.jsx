import { Layout } from "./layout/Layout";

export function App() {
  return (
    <>
      <Layout />
    </>
  );
}
