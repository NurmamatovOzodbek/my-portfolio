import { Header } from "../components";

export function Layout() {
  return (
    <>
      <Header />
    </>
  );
}
